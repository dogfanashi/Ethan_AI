# Ethan AI Website

Static frontend for Ethan AI.

## Run locally
1. Start the backend on port 8000.
2. Run this folder with: python -m http.server 5500
3. Open http://127.0.0.1:5500

Place your logo at assets/logo.png.
